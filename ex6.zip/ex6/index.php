<!--
 * Material utilizado para as aulas práticas da disciplinas da Faculdade de
 * Computação da Universidade Federal de Mato Grosso do Sul (FACOM / UFMS).
 * Seu uso é permitido para fins apenas acadêmicos, todavia mantendo a
 * referência de autoria.
 * @author Profª Jane Eleutério
-->
<!DOCTYPE html>
<!--
Essa página apenas redireciona a URL para View/index.php
-->
<html>
    <head>
        <title>Redirecionando....</title>
        <meta http-equiv="refresh" content="0; url=View/index.php">
    </head>
    <body>
        <!-- Não possui conteúdo -->
    </body>
</html>
